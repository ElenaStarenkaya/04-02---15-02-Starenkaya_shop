<?php

include('./functions.php');

$mysqli = mysqli_connect("localhost", "root", "", "starenkaya_shop");

$id = mysqli_escape_string($mysqli, $_GET[id]);

if($_SERVER['REQUEST_METHOD']==="POST") {
    $comment = $_POST['new_comment_text'];
    $query = "INSERT INTO `comments` (`user_id`, `text`, `product_id`) VALUES (1, '{$comment}', {$id})";
    mysqli_query($mysqli, $query);
    }

$query = "SELECT * FROM `product` WHERE id = " . $id;
$result = mysqli_query($mysqli, $query);

$product = mysqli_fetch_assoc($result);

$comment_query = "SELECT * FROM `comments` WHERE `product_id` = ". $id;
$comments_result = mysqli_query($mysqli, $comment_query);
$comments = mysqli_fetch_all($comments_result, MYSQLI_ASSOC);

$template = get_template('./templates/goods.php', ["product" => $product, "comments" => $comments]);

echo ($template);