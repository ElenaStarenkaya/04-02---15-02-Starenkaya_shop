<?php

include('./functions.php');

$mysqli = mysqli_connect("localhost", "root", "", "starenkaya_shop");  //ссылка на БД

$errors = [];

// if($_SERVER['REQUEST_METHOD']==="POST") {
//     if($_POST['pass']==$_POST['repeat_pass']) {
//         if(empty($_POST['login']) && empty($_POST['email'])){
// //создаем пользователя
//         }
//         else {
//             $errors[] = 'Не все поля заполнены';
//         }
    
//     } 
//     else {
//         //оповещаем пользователя об ошибке
//         $errors[] = 'Пароли не совпадают';
//     }
//     // $comment = $_POST['new_comment_text'];
//     // $query = "INSERT INTO `comments` (`user_id`, `text`, `product_id`) VALUES (1, '{$comment}', {$id})";
//     // mysqli_query($mysqli, $query);
//     }
if($_SERVER['REQUEST_METHOD']==="POST") {
    //валидирую все поля
    if(empty($_POST['pass'])) {
        $errors[] = 'Пароль не заполнен';
    }
    if(empty($_POST['repeat_pass'])) {
        $errors[] = 'Повтор пароля не заполнен';
    }
    if(empty($_POST['login'])) {
        $errors[] = 'Логин не введен';
    }
    if(empty($_POST['email'])) {
        $errors[] = 'email не заполнен';
    }
    if($_POST['pass'] != $_POST['repeat_pass']){
        $errors[] = 'Пароли не совпадают'; 
    }
    if(count($errors) == 0) {
        //создаю нового пользователя
        $pass_hash = password_hash($_POST['pass'], PASSWORD_DEFAULT);
        $login = mysqli_escape_string($mysqli, $_POST['login']);
        $email = mysqli_escape_string($mysqli, $_POST['email']);

        $query = "INSERT INTO `users` (`login`, `email`, `pass`) VALUES ('{$login}','{$email}', '{$pass_hash}')";
        mysqli_query($mysqli, $query);

        header('Location:/login.php');
    }
}


$template = get_template('./templates/registration.php', ['errors'=>$errors]);

echo ($template);