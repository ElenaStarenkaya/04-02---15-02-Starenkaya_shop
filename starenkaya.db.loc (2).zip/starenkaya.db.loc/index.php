<?php

include('./functions.php');
session_start();

// $mysqli = new mysqli("localhost", "root", "", "starenkaya_shop");

$mysqli = mysqli_connect("localhost", "root", "", "starenkaya_shop");

$user = null;

if(isset($_SESSION['user_id'])){  //если юзер авторизован
$user_query = "SELECT * FROM `users` WHERE `id` = {$_SESSION['user_id']}";
$user_result = mysqli_query($mysqli, $user_query);
$user = mysqli_fetch_assoc($user_result);
}

// $query = "SELECT * FROM `product` WHERE `category_id` = 1";
$query = "SELECT * FROM `product`";

$result = mysqli_query($mysqli, $query);

// $row = mysqli_fetch_assoc($result);

$products = [];
$row = null;
while($row = mysqli_fetch_assoc($result)){
    $products[] = $row;
}

$template = get_template('./templates/main.php', ["products" => $products, "user" => $user]);

echo ($template);