<?php

include('./functions.php');

$mysqli = mysqli_connect("localhost", "root", "", "starenkaya_shop");  //ссылка на БД

$errors = [];

if($_SERVER['REQUEST_METHOD']==="POST") {
if(empty($_POST['login'])) {
    $errors[] = 'Логин не заполнен';
}
if(empty($_POST['pass'])) {
    $errors[] = 'Пароль не заполнен';
}
if(count($errors) == 0) {
    $login = mysqli_escape_string($mysqli, $_POST['login']);
    $select_query = "SELECT * FROM `users` WHERE `login` = '{$login}'";
    $result = mysqli_query($mysqli,$select_query);
    $user = mysqli_fetch_assoc($result);

    if(password_verify($_POST['pass'], $user['pass'])) {
        //АВТОРИЗАЦИЯ
        // print('success');
        session_start(); - //подключение сессии
        $_SESSION['user_id'] = $user['id'];
        header('Location: /');  //переход на главную страницу
    } else {
        $errors[] = 'Неверный логин/пароль';
    }
}
}

$template = get_template('./templates/login.php', ['errors'=>$errors]);

echo ($template);