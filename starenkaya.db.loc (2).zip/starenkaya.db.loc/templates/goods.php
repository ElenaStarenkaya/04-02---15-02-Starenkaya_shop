<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP shop</title>
    <link rel="stylesheet" href="./css/main.css">
</head>
<body>
    <header>
<h1>starenkaya_shop.loc</h1>
</header>
<main>
    <div class="title">
    <h2 class="product_title"> <?php echo $product[title] ?></h2>
    <h3 class="product_price"><?php echo $product[price] ?> руб.</h3>
    </div>

<div class="wrapper">
    <div class="row">
    <img class="product_img" src="<?php echo $product[image] ?>" >
    <p class="product_desc"><?php echo $product[desc] ?></p>
    </div>
    <div class="comments">
        <?php foreach($comments as $comments): ?>
            <div class="comment">
                <p><?php echo $comments['text'] ?></p>
            </div>
            <?php endforeach; ?>

            <form method="POST" action="/product.php?id= <?php echo $product['id'] ?>">
        <input type="text" name="new_comment_text">
        <input type="submit" value="Отправить">
        </form>
    </div>
</div>

    </main>

<footer>
    <span>2022 &copy;</span>
</footer>
    
</body>
</html>