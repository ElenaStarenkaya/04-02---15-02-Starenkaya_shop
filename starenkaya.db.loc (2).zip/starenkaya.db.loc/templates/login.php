<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/main.css">
    <title>Registration</title>
</head>
<body>
<header>
<h1>starenkaya_shop.loc</h1>
</header>
<main>

    <form action="/login.php" method="POST">
        <input type="text" name="login" placeholder="логин">
        
        <input type="password" name="pass" placeholder="пароль">
        
        <input type="submit" value="Отправить"  name="submit">
    </form>
</main>
<?php if(count($errors) > 0): ?>
<div class="error">
    <ul>
        <?php foreach($errors as $item): ?>
           <li><?php echo $item ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>
    <footer>
    <span>2022 &copy;</span>
</footer>
</body>
</html>